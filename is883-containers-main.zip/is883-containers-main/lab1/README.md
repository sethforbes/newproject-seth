# About

We will deploy a simple app that is containerized via Docker.  The app will render a simple html page, but the web framework (fastAPI) can easily be extended for more advanced workloads.

