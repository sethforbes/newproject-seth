# About

A quick demo of using Cloud functions to power the fullfillment of a Dialogflow intent.  This will use a python-based cloud function to query an API to return a joke.

